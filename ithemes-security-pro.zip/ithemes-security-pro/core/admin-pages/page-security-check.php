<?php

wp_redirect( ITSEC_Core::get_security_check_page_url() );
exit;
