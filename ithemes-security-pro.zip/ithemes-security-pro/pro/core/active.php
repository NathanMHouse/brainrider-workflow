<?php
// Set up Content Directory Admin
require_once( 'class-itsec-core-admin.php' );
$itsec_core_admin = new ITSEC_Core_Admin();
$itsec_core_admin->run();
